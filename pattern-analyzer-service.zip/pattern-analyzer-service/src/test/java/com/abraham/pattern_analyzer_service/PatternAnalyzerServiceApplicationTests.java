package com.abraham.pattern_analyzer_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatternAnalyzerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
